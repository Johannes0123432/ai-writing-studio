"""
AI Writing Studio — Streamlit app
Legitimate drafting assistant for articles, books, and screenplays.
Uses user-supplied API keys for Gemini, Grok (xAI), or OpenRouter.
Focuses on structure, style control, grammar, and natural readability.
"""

from __future__ import annotations

import streamlit as st
from typing import List

from templates.structures import (
    ARTICLE_STRUCTURES,
    BOOK_STRUCTURES,
    SCREENPLAY_STRUCTURES,
    SCREENPLAY_FORMAT_GUIDE,
    get_default_structure,
    get_structure_outline,
    get_all_structures,
)
from utils.llm_clients import list_models, generate_text
from utils.quality import (
    check_grammar,
    compute_metrics,
    build_humanize_prompt,
    build_draft_system_prompt,
)

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="AI Writing Studio",
    page_icon="✍️",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("✍️ AI Writing Studio")
st.caption(
    "Draft articles, book chapters, and screenplays with structured templates, "
    "style control, grammar checking, and naturalness polishing. "
    "You supply the API keys. Always review and edit the output."
)

# ---------------------------------------------------------------------------
# Sidebar — provider & keys
# ---------------------------------------------------------------------------
with st.sidebar:
    st.header("LLM Provider")
    provider = st.selectbox(
        "Provider",
        ["Gemini", "Grok", "OpenRouter"],
        help="Grok uses the xAI API. OpenRouter gives access to many models.",
    )

    api_key = st.text_input(
        f"{provider} API Key",
        type="password",
        help="Key stays in this browser session only. Never stored on a server.",
    )

    models = list_models(provider, api_key)
    model = st.selectbox("Model", models, index=0)

    st.divider()
    st.subheader("Generation Settings")
    temperature = st.slider("Temperature", 0.0, 1.2, 0.7, 0.05)
    max_tokens = st.slider("Max tokens", 512, 8192, 4096, 256)

    st.divider()
    st.markdown(
        """
**Notes**
- This tool helps you draft and polish. Final responsibility for accuracy and originality is yours.
- Grammar check uses LanguageTool (local).
- “Humanize” improves rhythm and naturalness — it is **not** an AI-detector bypass.
- Always verify facts. The model can still make mistakes.
"""
    )

# ---------------------------------------------------------------------------
# Main form — project type & structure
# ---------------------------------------------------------------------------
col1, col2 = st.columns([1, 1])

with col1:
    category = st.radio(
        "Project type",
        ["Article", "Book", "Screenplay"],
        horizontal=True,
    )

with col2:
    structures = get_all_structures(category)
    default_name = get_default_structure(category)
    structure_names = list(structures.keys())
    default_idx = structure_names.index(default_name) if default_name in structure_names else 0
    structure_name = st.selectbox(
        "Structure / Template",
        structure_names,
        index=default_idx,
        help=structures[structure_names[default_idx]]["description"],
    )

# Show outline
outline = get_structure_outline(category, structure_name)
with st.expander("Structure outline (what the model will follow)", expanded=False):
    for item in outline:
        st.markdown(f"- {item}")
    if category == "Screenplay":
        st.markdown("---")
        st.markdown(SCREENPLAY_FORMAT_GUIDE)

# ---------------------------------------------------------------------------
# Style & content inputs
# ---------------------------------------------------------------------------
st.subheader("Style & Content")

style_presets = {
    "Clear professional (default)": "Clear, precise, professional prose. Varied sentence length. Avoid jargon unless necessary. Engaging but not flashy.",
    "Conversational / Friendly": "Warm, approachable, conversational tone as if explaining to a smart friend. Contractions OK. Light humor where appropriate.",
    "Journalistic / News": "Objective, concise, inverted-pyramid friendly. Active voice. Short paragraphs. Attribution for claims.",
    "Literary / Narrative": "Evocative, sensory, character-driven where relevant. Strong verbs, concrete images, controlled lyricism.",
    "Technical / Precise": "Exact terminology, logical flow, minimal ornamentation. Definitions for specialized terms.",
    "Academic (formal)": "Formal register, measured claims, hedging where evidence is incomplete. Clear structure and transitions.",
    "Humorous / Wry": "Dry wit, understatement, occasional playful asides. Still informative and structured.",
}

style_choice = st.selectbox("Reference style preset", list(style_presets.keys()), index=0)
custom_style = st.text_area(
    "Additional style notes (optional)",
    placeholder="e.g. Prefer short paragraphs, use American English, avoid passive voice…",
    height=80,
)

reference_sample = st.text_area(
    "Optional style sample (paste 200–800 words of writing you want the voice to resemble)",
    height=120,
    help="The model will imitate cadence and vocabulary level, not copy content.",
)

full_style = style_presets[style_choice]
if custom_style.strip():
    full_style += "\n\nAdditional notes: " + custom_style.strip()

st.subheader("What to write")

title = st.text_input("Title / Working title")
topic = st.text_area(
    "Core topic, premise, or logline",
    height=100,
    placeholder="Be specific. Include any must-have facts, characters, arguments, or constraints.",
)

key_points = st.text_area(
    "Key points, beats, or facts the draft must include (one per line)",
    height=120,
)

length_target = st.selectbox(
    "Approximate length target",
    [
        "Short (~400–700 words)",
        "Medium (~800–1500 words)",
        "Long (~1500–3000 words)",
        "Chapter / Full scene (let model decide based on structure)",
        "Custom (specify in extra instructions)",
    ],
    index=1,
)

extra_instructions = st.text_area(
    "Extra instructions (tone, audience, must-avoid, POV, etc.)",
    height=80,
)

# ---------------------------------------------------------------------------
# Generation
# ---------------------------------------------------------------------------
st.divider()
generate = st.button("Generate Draft", type="primary", use_container_width=True)

if "draft" not in st.session_state:
    st.session_state.draft = ""
if "humanized" not in st.session_state:
    st.session_state.humanized = ""
if "metrics" not in st.session_state:
    st.session_state.metrics = {}
if "grammar_issues" not in st.session_state:
    st.session_state.grammar_issues = []

if generate:
    if not api_key.strip():
        st.error("Please enter an API key in the sidebar.")
    elif not topic.strip() and not title.strip():
        st.error("Please provide at least a title or topic.")
    else:
        with st.spinner("Generating structured draft…"):
            system_prompt = build_draft_system_prompt(
                category=category,
                structure_name=structure_name,
                outline=outline,
                style=full_style,
                reference_sample=reference_sample,
                extra_instructions=extra_instructions,
            )

            user_prompt = f"""Write a complete {category.lower()} draft.

Title: {title or "(untitled)"}

Topic / Premise:
{topic}

Key points / must-include elements:
{key_points or "(none specified)"}

Length guidance: {length_target}

Follow the structure and style instructions exactly. Output only the draft itself (no meta commentary).
"""

            try:
                draft = generate_text(
                    provider=provider,
                    api_key=api_key,
                    model=model,
                    system_prompt=system_prompt,
                    user_prompt=user_prompt,
                    temperature=temperature,
                    max_tokens=max_tokens,
                )
                st.session_state.draft = draft
                st.session_state.humanized = ""  # reset
                st.session_state.metrics = compute_metrics(draft)
                st.success("Draft generated. Review below.")
            except Exception as e:
                st.error(f"Generation failed: {e}")

# ---------------------------------------------------------------------------
# Display & post-processing
# ---------------------------------------------------------------------------
if st.session_state.draft:
    st.subheader("Draft")
    draft_text = st.text_area(
        "Editable draft",
        value=st.session_state.draft,
        height=400,
        key="draft_area",
    )
    # Keep session in sync if user edits
    st.session_state.draft = draft_text

    # Metrics
    metrics = compute_metrics(draft_text)
    st.session_state.metrics = metrics

    mcols = st.columns(6)
    mcols[0].metric("Words", metrics.get("word_count", 0))
    mcols[1].metric("Sentences", metrics.get("sentence_count", 0))
    mcols[2].metric("Avg sent. len", metrics.get("avg_sentence_length", 0))
    mcols[3].metric("Sent. len std", metrics.get("sentence_length_std", 0),
                    help="Higher usually means more natural rhythm variation")
    mcols[4].metric("Unique word ratio", metrics.get("unique_word_ratio", 0))
    mcols[5].metric("Common AI-phrase hits", metrics.get("ai_tell_phrase_count", 0))

    if metrics.get("flesch_reading_ease") is not None:
        st.caption(
            f"Flesch Reading Ease: {metrics['flesch_reading_ease']:.1f} · "
            f"Grade level: {metrics.get('flesch_kincaid_grade', 'n/a')}"
        )

    # Action buttons
    b1, b2, b3, b4 = st.columns(4)

    with b1:
        if st.button("Run Grammar Check", use_container_width=True):
            with st.spinner("Checking grammar…"):
                corrected, issues = check_grammar(draft_text)
                st.session_state.draft = corrected
                st.session_state.grammar_issues = issues
                st.rerun()

    with b2:
        if st.button("Polish for Naturalness", use_container_width=True):
            if not api_key.strip():
                st.error("API key required for polishing.")
            else:
                with st.spinner("Polishing rhythm and naturalness…"):
                    try:
                        humanize_prompt = build_humanize_prompt(draft_text, full_style)
                        polished = generate_text(
                            provider=provider,
                            api_key=api_key,
                            model=model,
                            system_prompt="You are a careful developmental editor focused on natural prose.",
                            user_prompt=humanize_prompt,
                            temperature=0.65,
                            max_tokens=max_tokens,
                        )
                        st.session_state.humanized = polished
                        st.session_state.draft = polished  # replace current draft
                        st.session_state.metrics = compute_metrics(polished)
                        st.rerun()
                    except Exception as e:
                        st.error(f"Polish failed: {e}")

    with b3:
        if st.button("Copy to clipboard helper", use_container_width=True):
            st.code(draft_text, language=None)

    with b4:
        st.download_button(
            "Download .txt",
            data=draft_text,
            file_name=f"{(title or 'draft').replace(' ', '_')[:40]}.txt",
            mime="text/plain",
            use_container_width=True,
        )

    # Grammar issues
    if st.session_state.grammar_issues:
        with st.expander(f"Grammar / style issues found ({len(st.session_state.grammar_issues)})"):
            for issue in st.session_state.grammar_issues[:30]:
                st.markdown(f"- **{issue.get('message', '')}**")
                if issue.get("replacements"):
                    st.caption("Suggestions: " + ", ".join(issue["replacements"]))
            if len(st.session_state.grammar_issues) > 30:
                st.caption("… and more")

    # Final reminder
    st.info(
        "Always fact-check, fact-verify any numbers or claims, and perform a human edit pass. "
        "This tool improves structure and readability; it does not guarantee originality or detector scores."
    )
else:
    st.info("Configure the options above and click **Generate Draft** to begin.")
